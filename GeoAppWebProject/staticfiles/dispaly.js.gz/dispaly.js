 
// let table_tag = document.getElementsByClassName('table_data')
//             //  var table = '';
//             //  var rows = JSON.parse("{{natcoordata|escapejs}}");
//             //  for (var r = 0; r<rows.length;r++){
//             //      var rowitem = rows[r]
                
//             //      table+='<tr>';
//             //          for (var c=0;c < rowitem.length; c++){
//             //              table += '<td>'+ rowitem[c]+ '</td>';
                    
//             //          }
//             //      table+='</tr>'

// console.log(table_tag)
         